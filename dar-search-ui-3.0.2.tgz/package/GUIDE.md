# How to implement DAR Search UI

DAR Search UI is a JavaScript-component that enables users to enter a Danish address in a single input field.

## Usage

DAWA Autocomplete may be used as an ES module, installed using NPM, or it may be loaded into the browser using a `<script>`-tag from a CDN. 

**Important notice:** Setting up Dar Search UI requires a valid token that can be aquired fom https://datafordeler.dk 

For a working demo page, please see [https://septima.dk/dar-search-demo/](https://septima.dk/dar-search-demo/)

## Setting up CSS

Add the necessary CSS styles in your HTML `<head>` section.

Option 1: As a link
```html
<link rel="stylesheet" href="./dawa-autocomplete.css" />
```

Option 2: With the raw CSS rules
```html
<style>
  /* DAWA-autocomplete2 styles*/
  .autocomplete-container {
    /* relative position for at de absolut positionerede forslag får korrekt placering.*/
    position: relative;
    width: 100%;
    max-width: 30em;
  }

  .autocomplete-container input {
    /* Både input og forslag får samme bredde som omkringliggende DIV */
    width: 100%;
    box-sizing: border-box;
  }

  .dawa-autocomplete-suggestions {
    margin: 0.3em 0 0 0;
    padding: 0;
    text-align: left;
    border-radius: 0.3125em;
    background: #fcfcfc;
    box-shadow: 0 0.0625em 0.15625em rgba(0, 0, 0, 0.15);
    position: absolute;
    left: 0;
    right: 0;
    z-index: 9999;
    overflow-y: auto;
    box-sizing: border-box;
  }

  .dawa-autocomplete-suggestions .dawa-autocomplete-suggestion {
    margin: 0;
    list-style: none;
    cursor: pointer;
    padding: 0.4em 0.6em;
    color: #333;
    border: 0.0625em solid #ddd;
    border-bottom-width: 0;
  }

  .dawa-autocomplete-suggestions .dawa-autocomplete-suggestion:first-child {
    border-top-left-radius: inherit;
    border-top-right-radius: inherit;
  }

  .dawa-autocomplete-suggestions .dawa-autocomplete-suggestion:last-child {
    border-bottom-left-radius: inherit;
    border-bottom-right-radius: inherit;
    border-bottom-width: 0.0625em;
  }

  .dawa-autocomplete-suggestions
    .dawa-autocomplete-suggestion.dawa-selected,
  .dawa-autocomplete-suggestions .dawa-autocomplete-suggestion:hover {
    background: #f0f0f0;
  }
</style>
```

## Script option 1: Implement from CDN

Working example at https://septima.dk/dar-search-demo/migration-cdn/

Add the necessary CSS styles in your HTML `<head>` section:
```html
<script src="./dawa-autocomplete.iife.js"></script> // Adjust URL as necessary
```
Then add the following markup and script to your HTML `<body>` section:
```html
<!-- HTML -->
<label for="search-input">Søg efter adresser</label>
<div class="autocomplete-container">
  <input type="search" id="search-input" />
</div>

<!-- Javascript -->
<script>
  dawaAutocomplete.dawaAutocomplete(document.getElementById("demoCDN"), {
    select: function (selected) {
      console.log("Selected address:", selected);
    },
    token: "your-token-here",
  });
</script>
```

## Script option 2: Implement from NPM package

**TODO** Update when an NPM package is made available.

When building from an NPM package using your favorite bundler, add this Javascript to your source:
```javascript
/* your-source.js soon to be your-bundled-script.js */
import { dawaAutocomplete } from "dar-search-ui";
var inputElement = document.getElementById("demoES");
var component = dawaAutocomplete(inputElement, {
  select: function (selected) {
    console.log("Valgt adresse: ", selected);
  },
  token: "your-token-here"
});
```
Then add the following markup and script to your HTML `<body>` section:
```html
<!-- HTML -->
<label for="search-input">Søg efter adresser</label>
<div class="autocomplete-container">
  <input type="search" id="search-input" />
</div>

<!-- Javascript -->
<script src="your-bundled-script.js"></script>
```

## Script option 3: Implement using ES module

Working example at https://septima.dk/dar-search-demo/migration-esm/

This is similar to bundling a script from an NPM package.
Add the following markup and script to your HTML `<body>` section:
```html
<!-- HTML -->
<label for="search-input">Søg efter adresser</label>
<div class="autocomplete-container">
  <input type="search" id="search-input" />
</div>

<!-- Javascript -->
<script type="module">
  import { dawaAutocomplete } from "./dawa-autocomplete.esm.js"; // Change this URL as appropriate
  var inputElement = document.getElementById("demoES");
  var component = dawaAutocomplete(inputElement, {
    select: function (selected) {
      console.log("Valgt adresse: ", selected);
    },
    token: "your-token-here"
  });
</script>
```
