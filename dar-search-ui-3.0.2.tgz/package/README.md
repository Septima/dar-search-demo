# dar-search-ui

A UI component for implementing DAR search in Javascript applications.

## Quick links

* [DAR search demo page](https://septima.dk/dar-search-demo/)
* [DawaAutocomplete demo page (legacy version)](https://dawadocs.dataforsyningen.dk/demo/autocomplete/demo.html)

## Implementing DAR search UI

To implement DAR search UI, [check the implementation guide.](./GUIDE.md)

To migrate from DAWA-autocomplete2, [check the migration guide.](./MIGRATION-GUIDE.md)

## Getting started with local build

**Prerequisites:** 
- [git](https://git-scm.com/) 
- [Node.js](https://nodejs.org)
- [pnpm](https://pnpm.io/)

1. Clone repo 
   ```
   git clone https://github.com/septima/dar-search-ui
   cd dar-search-ui
   ```
2. Install dependencies
   ```
   pnpm i
   ```
3. Run development server
   ```
   pnpm dev
   ```
4. Open browser and point to http://localhost:8000

## Run tests

Run the tests using Playwright test runner:
```
pnpm test
```

## Build for production

```
pnpm build
```
Build files are found i `dist/` folder.
