# Migration guide

If you have already implemented DAWA-autocomplete2 from https://github.com/SDFIdk/dawa-autocomplete2 ,
here is how to migrate to dar-search.

**General directions** 
To migrate to dar-search-ui, you'll need to:

1. Fetch the Javascript from a different source
2. Add a `token` option when initializing the script
3. Add a label to your HTML for accessibility

## Migrate Javascript from CDN

If you used the CDN script from DAWA-autocomplete2:

1. Change the Javascipt `<script>` element from 
   ```
   <script src="https://cdn.dataforsyningen.dk/dawa/assets/dawa-autocomplete2/1.0.2/dawa-autocomplete2.min.js"></script>
   ```
   to
   ```
   <script src="dawa-autocomplete.iife.js"></script>
   ```
2. Aquire a valid `token` and add it you your initialization script:
   ```
   <script>
    dawaAutocomplete.dawaAutocomplete(document.getElementById('dawa-autocomplete-input'), {
      select: function(selected) {
        console.log('Valgt adresse: ' + selected.title);
      },
      token: "your-token-here"
    });
   </script>
   ```
   Notice that the API returns a different object. For example, if you used `selected.tekst` in the example above in the past, you now should use `selected.title`

A complete example can be found here: https://septima.dk/dar-search-demo/migration-cdn

## Migrate Javascript from NPM package

The `dawa-autocomplete2` NPM package will be deprecated. Instead install the `dar-search-ui` package.
```
npm i --save dar-search-ui
```
Then change your source Javascript to use the new package.

Using CommonJS syntax - example at https://septima.dk/dar-search-demo/migration-cjs/
```javascript
/* Old implementation */
/*
var dawaAutocomplete2 = require('dawa-autocomplete2');
var inputElm = document.getElementById('dawa-autocomplete-input');
var component = dawaAutocomplete2.dawaAutocomplete(inputElm, {
  select: function(selected) {
    console.log('Valgt adresse: ' + selected.tekst);
  }
});
*/

/* New implementation*/
var dawaAutocomplete = require("../dawa-autocomplete.cjs.js"); // Change the package reference
var inputElm = document.getElementById("dawa-autocomplete-input");
var component = dawaAutocomplete.dawaAutocomplete(inputElm, {
  select: function (selected) {
    console.log("Valgt adresse:", selected); // Note that the `tekst` property is deprecated
  },
  token: "your-token-here", // Add the token option
});
```

Or Using ES module syntax - example at https://septima.dk/dar-search-demo/migration-esm/
```javascript
import { dawaAutocomplete } from 'dar-search-ui'
const inputElm = document.getElementById('dawa-autocomplete-input')
const component = dawaAutocomplete(inputElm, {
  select: function(selected) {
    console.log('Valgt adresse: ' + selected);
  },
  token: 'your-token-here´,
})
```

## Improve HTML accessibility

To conform to requiremetns for accessibility, you should add a `<label>`-element for the search input field. You can place it anywhere you like if you use the `for` attribute to link it to the search input like in the example below.
```html
<!-- OLD HTML markup -->
<!--
<div class="autocomplete-container">
  <input type="search" id="demoCDN" />
</div>
-->

<!-- Adjusted HTML markup -->
<label for="demoCDN">Søg efter adresser</label>
<div class="autocomplete-container">
  <input type="search" id="demoCDN" />
</div>
```
