// Legacy DOM manipulation
import { dawaAutocomplete } from "./src/legacy.js";

// Web component
import { DarSearchInput } from "./src/web-component.js";

// Raw API class
import { DarSearchAPI } from "./src/api.js";

// Legacy DOM component must be exported as default
export default dawaAutocomplete;

// Export the imports
export {
  dawaAutocomplete,
  DarSearchInput,
  DarSearchAPI
}
